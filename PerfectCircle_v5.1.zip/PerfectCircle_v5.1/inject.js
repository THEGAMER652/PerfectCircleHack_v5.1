(function() {
  let patchActive = true;

  const _toFixed = Number.prototype.toFixed;
  Number.prototype.toFixed = function(digits) {
    const result = _toFixed.call(this, digits);
    if (patchActive && parseFloat(result) >= 90) {
      return (100).toFixed(digits);
    }
    return result;
  };

  const _round = Math.round;
  Math.round = function(x) {
    if (patchActive && x >= 90 && x <= 100) {
      return 100;
    }
    return _round(x);
  };

  setTimeout(() => { patchActive = false; }, 30000);
})();
