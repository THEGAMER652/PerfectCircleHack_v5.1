const btn = document.getElementById('drawBtn');
const status = document.getElementById('status');

btn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url || !tab.url.includes('neal.fun/perfect-circle')) {
    status.textContent = '⚠ Open neal.fun/perfect-circle first!';
    status.className = 'status error';
    return;
  }

  btn.disabled = true;
  status.textContent = 'click the white dot...';
  status.className = 'status active';

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    func: injectCircleBot
  });

  setTimeout(() => {
    status.textContent = 'injected! click the dot';
    status.className = 'status done';
    btn.disabled = false;
  }, 500);
});

function injectCircleBot() {
  if (window.__CircleBot?.destroy) window.__CircleBot.destroy();

  const state = {
    center: null,
    target: null,
    running: false,
    duration: 2800,
    ratio: 0.34,
    rafId: null
  };

  function clampRadius(cx, cy, r) {
    const M = 8;
    return Math.max(10, Math.min(r,
      Math.min(cx-M, cy-M, window.innerWidth-cx-M, window.innerHeight-cy-M)));
  }

  function firePtr(target, type, x, y, down) {
    target.dispatchEvent(new PointerEvent(type, {
      bubbles:true, cancelable:true, pointerId:1, pointerType:'mouse',
      buttons: (down && type!=='pointerup') ? 1 : 0,
      pressure: type==='pointerup' ? 0 : (down ? 0.5 : 0),
      clientX:x, clientY:y
    }));
  }

  function fireMouse(target, type, x, y, down) {
    target.dispatchEvent(new MouseEvent(type, {
      bubbles:true, cancelable:true,
      buttons: (down && type!=='mouseup') ? 1 : 0,
      clientX:x, clientY:y
    }));
  }

  function runOnce() {
    if (!state.center || state.running) return;
    const cx = state.center.x, cy = state.center.y;
    const r = clampRadius(cx, cy,
      Math.min(window.innerWidth, window.innerHeight) * state.ratio);
    const startX = Math.round(cx + r), startY = Math.round(cy);
    state.target = document.elementFromPoint(startX, startY) || document.body;

    firePtr(state.target, 'pointermove', startX, startY, false);
    fireMouse(state.target, 'mousemove', startX, startY, false);
    firePtr(state.target, 'pointerdown', startX, startY, true);
    fireMouse(state.target, 'mousedown', startX, startY, true);

    const t0 = performance.now();
    state.running = true;

    function step(now, lastP) {
      const p = Math.min(1, (now - t0) / state.duration);
      for (let i = 1; i <= 8; i++) {
        const q = lastP + (p - lastP) * (i / 8);
        const th = q * Math.PI * 2;
        const x = cx + r * Math.cos(th);
        const y = cy + r * Math.sin(th);
        firePtr(state.target, 'pointermove', x, y, true);
        fireMouse(state.target, 'mousemove', x, y, true);
      }
      if (p < 1) {
        state.rafId = requestAnimationFrame(n => step(n, p));
      } else {
        firePtr(state.target, 'pointermove', startX, startY, true);
        fireMouse(state.target, 'mousemove', startX, startY, true);
        firePtr(state.target, 'pointerup', startX, startY, false);
        fireMouse(state.target, 'mouseup', startX, startY, false);
        state.running = false;
      }
    }
    state.rafId = requestAnimationFrame(n => step(n, 0));
  }

  function onCenterClick(e) {
    e.preventDefault();
    e.stopPropagation();
    window.removeEventListener('click', onCenterClick, true);
    state.center = { x: e.clientX, y: e.clientY };
    setTimeout(runOnce, 50);
  }

  window.addEventListener('click', onCenterClick, true);
  window.__CircleBot = { destroy: () => {
    cancelAnimationFrame(state.rafId);
    window.removeEventListener('click', onCenterClick, true);
    delete window.__CircleBot;
  }};
}
